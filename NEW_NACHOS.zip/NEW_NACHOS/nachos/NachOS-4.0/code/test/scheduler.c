#include "syscall.h"

void main(){
    PrintString("___PING PONG___");
    Exec("ping");
    Exec("pong");
    PrintString("___FINISH___");

    //Halt();
}