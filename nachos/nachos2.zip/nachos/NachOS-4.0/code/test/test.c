#include "syscall.h"

void main(){
    PrintString("A");
    Halt();
}