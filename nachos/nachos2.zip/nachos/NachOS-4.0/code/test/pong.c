//Print B
#include "syscall.h"

void main(){
    int i;
    //PrintString("----PONG FUNC----");
    for (i = 0; i < 10; i++)
    {
        PrintChar('B');
    }
}