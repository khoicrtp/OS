// synchconsole.cc 
//	Routines providing synchronized access to the keyboard 
//	and console display hardware devices.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "synchconsole.h"

static Semaphore *synchReadAvail;
static Semaphore *synchWriteAvail;
static Semaphore *RLineBlock;
static Semaphore *WLineBlock;

//----------------------------------------------------------------------
// ConsoleInterruptHandlers
// 	Wake up the thread that requested the I/O.
//----------------------------------------------------------------------

static void SynchReadFunct(int arg) { synchReadAvail->V(); }
static void SynchWriteFunct(int arg) { synchWriteAvail->V(); }


//----------------------------------------------------------------------
//   SynchConsole::SynchConsole()
//	Creates a synchronous console device with standard input and output
//----------------------------------------------------------------------

SynchConsole::SynchConsole()
{
	cons = new Console(NULL,NULL,SynchReadFunct,SynchWriteFunct,0);
	synchReadAvail = new Semaphore("Synch Read Avail",0);
	synchWriteAvail = new Semaphore("Synch Write Avail",0);
	RLineBlock = new Semaphore("Read Synch Line Block",1);
	WLineBlock = new Semaphore("Write Synch Line Block",1);
}

//----------------------------------------------------------------------
//   SynchConsole::SynchConsole(char *in, char *out)
//	Creates a synchronous console device with filenames
//----------------------------------------------------------------------

SynchConsole::SynchConsole(char *in, char *out)
{
	cons = new Console(in,out,SynchReadFunct,SynchWriteFunct,0);
	synchReadAvail = new Semaphore("Synch Read Avail",0);
	synchWriteAvail = new Semaphore("Synch Write Avail",0);
	RLineBlock = new Semaphore("Read Synch Line Block",1);
	WLineBlock = new Semaphore("Write Synch Line Block",1);
}

//----------------------------------------------------------------------
//   SynchConsole::~SynchConsole()
//	Delete a console device
//----------------------------------------------------------------------
	
SynchConsole::~SynchConsole()
{
	delete cons;
	delete synchReadAvail;
	delete synchWriteAvail;
	delete RLineBlock;
	delete WLineBlock;
}

//----------------------------------------------------------------------
//   int SynchConsole::Write(char *into, int numBytes)
//	Writes numBytes of into buffer to I/O device 
//	Returns the number of bytes written
//----------------------------------------------------------------------

int SynchConsole::Write(char *from, int numBytes)
{
	int loop;			// General purpose counter

	WLineBlock->P();			// Block for the line

//	printf("[%s]:\n",currentThread->getName());	//DEBUG: Print thread

	for (loop = 0; loop < numBytes; loop++)
	{
		cons->PutChar(from[loop]);		// Write and wait
		synchWriteAvail->P();			// Block for a character
	}

	WLineBlock->V();				// Free Up
	return numBytes;				// Return the bytes out
}

//----------------------------------------------------------------------
//   int SynchConsole::Read(char *into, int numBytes)
//	Read numBytes of into buffer to I/O device 
//	Returns the number of bytes written  (may be less if CR or ^D)
//----------------------------------------------------------------------

int
SynchConsole::Read(char *into, int numBytes)
{
	int loop;
	int eolncond = FALSE;
	char ch;

	for (loop = 0; loop < numBytes; loop++)
		into[loop] = 0;

	loop = 0;

	RLineBlock->P();				// Block for a read line

//	printf("{%s}:\n",currentThread->getName());	// DEBUG print thread

	while ( (loop < numBytes) && (eolncond == FALSE) )
	{
		do
		{
			synchReadAvail->P();		// Block for single char
			ch = cons->GetChar();		// Get a char (could)
		} while ( ch == EOF);

		if ( (ch == '\012') || (ch == '\001') )
		{
			eolncond = TRUE;
		}
		else
		{
			into[loop] = ch;		// Put the char in buf
			loop++;				// Auto inc
		}
	}

	RLineBlock->V();				// UnBLock

	if (ch == '\001')				// CTRL-A Returns -1
		return -1;				// For end of stream
	else
		return loop;				// How many did we rd
}
//----------------------------------------------------------------------
// SynchConsoleInput::SynchConsoleInput
//      Initialize synchronized access to the keyboard
//
//      "inputFile" -- if NULL, use stdin as console device
//              otherwise, read from this file
//----------------------------------------------------------------------

SynchConsoleInput::SynchConsoleInput(char *inputFile)
{
    consoleInput = new ConsoleInput(inputFile, this);
    lock = new Lock("console in");
    waitFor = new Semaphore("console in", 0);
}

//----------------------------------------------------------------------
// SynchConsoleInput::~SynchConsoleInput
//      Deallocate data structures for synchronized access to the keyboard
//----------------------------------------------------------------------

SynchConsoleInput::~SynchConsoleInput()
{ 
    delete consoleInput; 
    delete lock; 
    delete waitFor;
}

//----------------------------------------------------------------------
// SynchConsoleInput::GetChar
//      Read a character typed at the keyboard, waiting if necessary.
//----------------------------------------------------------------------

char
SynchConsoleInput::GetChar()
{
    char ch;

    lock->Acquire();
    waitFor->P();	// wait for EOF or a char to be available.
    ch = consoleInput->GetChar();
    lock->Release();
    return ch;
}

//----------------------------------------------------------------------
// SynchConsoleInput::CallBack
//      Interrupt handler called when keystroke is hit; wake up
//	anyone waiting.
//----------------------------------------------------------------------

void
SynchConsoleInput::CallBack()
{
    waitFor->V();
}

//----------------------------------------------------------------------
// SynchConsoleOutput::SynchConsoleOutput
//      Initialize synchronized access to the console display
//
//      "outputFile" -- if NULL, use stdout as console device
//              otherwise, read from this file
//----------------------------------------------------------------------

SynchConsoleOutput::SynchConsoleOutput(char *outputFile)
{
    consoleOutput = new ConsoleOutput(outputFile, this);
    lock = new Lock("console out");
    waitFor = new Semaphore("console out", 0);
}

//----------------------------------------------------------------------
// SynchConsoleOutput::~SynchConsoleOutput
//      Deallocate data structures for synchronized access to the keyboard
//----------------------------------------------------------------------

SynchConsoleOutput::~SynchConsoleOutput()
{ 
    delete consoleOutput; 
    delete lock; 
    delete waitFor;
}

//----------------------------------------------------------------------
// SynchConsoleOutput::PutChar
//      Write a character to the console display, waiting if necessary.
//----------------------------------------------------------------------

void
SynchConsoleOutput::PutChar(char ch)
{
    lock->Acquire();
    consoleOutput->PutChar(ch);
    waitFor->P();
    lock->Release();
}

//----------------------------------------------------------------------
// SynchConsoleOutput::CallBack
//      Interrupt handler called when it's safe to send the next 
//	character can be sent to the display.
//----------------------------------------------------------------------

void
SynchConsoleOutput::CallBack()
{
    waitFor->V();
}
