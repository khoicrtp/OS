#include "syscall.h"

int main()
{
  Halt();
}